#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom jsonlite fromJSON
#' @importFrom jsonlite toJSON
#' @importFrom purrr map
#' @importFrom rzmq connect.socket
#' @importFrom rzmq init.context
#' @importFrom rzmq init.socket
#' @importFrom rzmq receive.socket
#' @importFrom rzmq receive.string
#' @importFrom rzmq send.raw.string
#' @importFrom rzmq set.linger
#' @importFrom rzmq set.reconnect.ivl
#' @importFrom rzmq set.send.timeout
## usethis namespace: end
NULL
